//Oluwakorede Bolaji-Anibaba, Id: S1903345
package com.example.earthquakes;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;
import java.io.IOException;
import java.io.StringReader;
import java.util.LinkedList;


public class EarthquakesParser
{

    LinkedList <Earthquakes> earthquakeList = null;


    LinkedList <String>  titleList = null;


    public LinkedList<Earthquakes> parseRSSString(String rssString)
    {
        Earthquakes earthquakes = new Earthquakes();

        try
        {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser xpp = factory.newPullParser();
            xpp.setInput( new StringReader( rssString ) );
            int eventType = xpp.getEventType();

            while (eventType != XmlPullParser.END_DOCUMENT)
            {


                if(eventType == XmlPullParser.START_TAG)
                {

                    if (xpp.getName().equalsIgnoreCase("channel"))
                    {
                        earthquakeList  = new LinkedList<Earthquakes>();
                        titleList     = new LinkedList<String>();


                        for(int i = 0; i<11; i++)
                        {
                            eventType = xpp.next();

                        }

                    }
                    else
                    if (xpp.getName().equalsIgnoreCase("item"))
                    {
                        earthquakes = new Earthquakes();
                    }
                    else
                    if (xpp.getName().equalsIgnoreCase("title"))
                    {
                        String temp = xpp.nextText();
                        earthquakes.setTitle(temp);


                    }
                    else

                        if (xpp.getName().equalsIgnoreCase("description"))
                        {

                            String temp = xpp.nextText();

                            String[] selectTemp = temp.split(";");

                            for (String s : selectTemp) {
                                earthquakes.setDescription(s);
                                System.out.println(s);
                            }




                        }
                        else

                            if (xpp.getName().equalsIgnoreCase("pubDate"))
                            {

                                String temp = xpp.nextText();
                                earthquakes.setPubDate(temp);
                            }

                }
                else
                if(eventType == XmlPullParser.END_TAG)
                {
                    if (xpp.getName().equalsIgnoreCase("item"))
                    {
                        earthquakeList.add(earthquakes);
                        titleList.add(earthquakes.getTitle());
                    }
                    else
                    if (xpp.getName().equalsIgnoreCase("channel"))
                    {
                        int size;
                        size = earthquakeList.size();
                    }
                }


                eventType = xpp.next();
            }

        }

        catch (XmlPullParserException e)
        {
            System.out.println("Parsing Error "+e.toString());
        }

        catch (IOException e)
        {
            System.out.println("Parsing Error "+e.toString());
        }
        return earthquakeList;
    }


}