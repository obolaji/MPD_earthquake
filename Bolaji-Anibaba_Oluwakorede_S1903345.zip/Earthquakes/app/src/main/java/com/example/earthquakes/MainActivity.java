//Oluwakorede Bolaji-Anibaba, Id: S1903345
package com.example.earthquakes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.Collections;
import java.util.LinkedList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    EarthquakesReader rssReader = new EarthquakesReader();
    EarthquakesParser rssParser = new EarthquakesParser();


    private ListView Earthquakes_LIST;
    private TextView Earthquakes_VIEW;
    private ArrayAdapter arrayAdapter;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Earthquakes_LIST = (ListView)findViewById(R.id.Earthquakes_LIST);
        Earthquakes_VIEW = (TextView)findViewById(R.id.Earthquakes_VIEW);


        Earthquakes_LIST.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String selectedTitle = (String)parent.getItemAtPosition(position);

                for(int i = 0; i < rssParser.earthquakeList.size();i++)
                {
                    if(selectedTitle.equals(rssParser.earthquakeList.get(i).getTitle()))
                    {
                        Earthquakes_VIEW.setText(rssParser.earthquakeList.get(i).toString());
                        break;


                    }
                }


            }
        });




    }
    public void Refresh(View view)
    {
        asyncRefresh(view);
    }
    public void asyncRefresh(View view)
    {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(new Runnable() {

            @Override
            public void run() {


                LinkedList<Earthquakes> earthquakesList = null;

                rssReader.FetchRSS();


                rssParser.parseRSSString(rssReader.getRssString());
                //System.out.println("STRING: "+ rssParser.earthquakesList.get(0));

                arrayAdapter = new ArrayAdapter(MainActivity.this, android.R.layout.simple_list_item_1, rssParser.titleList);

                handler.post(new Runnable() {
                    @Override
                    public void run() {
                       Earthquakes_LIST.setAdapter(arrayAdapter);
                        Earthquakes_VIEW.setText("");

                    }
                });

                handler.post(new Runnable() {
                    @Override
                    public void run() {


                    }
                });



            }
        });
    }

    public void viewMap(View view) {
        Intent intent = new Intent(MainActivity.this, MapsActivity.class);

        startActivity(intent);
    }




}



